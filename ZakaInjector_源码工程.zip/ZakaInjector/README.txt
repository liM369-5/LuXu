陆续注入器 —— 源码工程说明
==============================

一、这是什么
    安卓悬浮窗注入器。手动机注入：把 APK 里内置的 payload 释放到游戏私有目录，
    再借 Shizuku（首选）或 Root（备选）的 shell 身份，覆盖进游戏 LuaSource 目录。
    全程：通道检测 → 查游戏进程 → 定位目标目录 → 按时间戳备份 → 落 tmp → 覆盖
    → 回读比对校验值 → 出问题一键回滚。日志写 inject.log。

二、工程结构
    app/src/main/java/com/zaka/injector/
        MainActivity.java              主界面（状态卡 / 主键 / 日志卡）
        core/AppConfig.java            配置：目标字节名、目录候选、包名
        core/ByteName.java             字节名编码（0xFF − 字符码，等长）
        core/ChannelManager.java       通道统一调度
        core/ShellRunner.java          shell 执行抽象接口
        core/ShizukuRunner.java        Shizuku 通道（newProcess 走反射）
        core/RootRunner.java           Root 备选通道
        core/ProcessIo.java            进程读写与超时
        inject/InjectEngine.java       流水线接口
        inject/DefaultInjectEngine.java 主流水线实现
        inject/PayloadManager.java     payload 释放
        inject/BackupManager.java      备份与回滚
        inject/StepEvent.java          步骤事件
        log/InjectLog.java             日志
        perm/PermHelper.java           悬浮窗 / 通知权限
        ui/FloatingService.java        悬浮球前台服务
        ui/PanelView.java              展开面板
        ui/Theme.java                  配色与系统栏
        ui/XLLogo.java                 绘制 logo

    app/src/main/assets/payload/       ← 要注入的模块放这里（见第五节）
    app/src/main/res/                  资源（主题 / 颜色 / 图标）
    app/zaka.jks                       签名密钥

三、编译
    1. 装 JDK 17、Android SDK（compileSdk 34 / build-tools 34）
    2. 改 local.properties 里的 sdk.dir 为你的 SDK 路径
    3. 命令行：
         ./gradlew :app:assembleRelease
       没有 wrapper 就用系统 gradle：
         gradle :app:assembleRelease
    4. 产物：app/build/outputs/apk/release/app-release.apk
       已配好 release 签名，编出来就是可安装的正式包。

四、签名
    密钥文件：app/zaka.jks
    类型    ：JKS
    keyAlias：zaka
    口令    ：zaka123456（store 和 key 同一个）
    签名信息已在 app/build.gradle 的 signingConfigs.release 里写死，
    想换自己的密钥，改那一段即可：
        storeFile file("zaka.jks")
        storePassword "你的store口令"
        keyAlias "你的别名"
        keyPassword "你的key口令"

    命令行验签 / 手动签：
        apksigner verify --print-certs app-release.apk
        apksigner sign --ks app/zaka.jks --ks-key-alias zaka \
            --ks-pass pass:zaka123456 --key-pass pass:zaka123456 \
            --out signed.apk app-release.apk

    用同一个密钥签，新版本可以直接覆盖安装，不用先卸载。

五、payload（要注入的模块）
    位置：app/src/main/assets/payload/
    首次启动由 PayloadManager 释放到 App 自己的私有目录，
    注入时再搬到游戏的 Saved/LuaSource/ 下。
    现工程里放的是：CHECKEQUIPLOGIC.LUA
    要换成别的模块：
        1) 把新文件丢进 assets/payload/
        2) 改 core/AppConfig.java 里的 payload 名和 TARGET_NAME（目标字节名）
    目标名是按原始字节写死的，不走运行时换算。

六、注入链路
    Shizuku 通道：Shizuku.newProcess 在部分依赖版本里是私有方法，
                  工程里走反射调用，别改回直接调用。
    Root 通道   ：su -c。仅在没有 Shizuku 时启用。
    目录候选    ：AppConfig 里列了若干条，覆盖 DFM/DFM/Saved/LuaSource 等形态。

七、使用步骤
    装 APK → 给悬浮窗 + 通知权限 → 启动 Shizuku 并授权 → 开游戏 →
    点悬浮球 → 注入。

八、常见情况
    · 注入时提示「原文件都不存在，按新增处理」
      = 游戏目录里没有这个字节名的文件，多半是目标名跟实际不一致。
      把当时的 inject.log 拿出来对一下目标字节名即可。
    · 备份失败会直接停手，不会硬写。
    · 回读校验值对不上会自动走回滚。

九、版本
    versionName 1.1 / versionCode 2
    minSdk 26 / targetSdk 34 / compileSdk 34
