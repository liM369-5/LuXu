package com.zaka.injector.core;

import android.content.pm.PackageManager;

import rikka.shizuku.Shizuku;

/** Shizuku 通道（首选）：以 shell 身份跑命令，不需要 root */
public class ShizukuRunner implements ShellRunner {

    public static final int PERMISSION_CODE = 0x5A4B;

    @Override
    public String name() {
        return "Shizuku";
    }

    /** Shizuku 服务活着 + 权限已给 */
    public static boolean ready() {
        try {
            if (!Shizuku.pingBinder()) {
                return false;
            }
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 服务活着但权限没给 */
    public static boolean needPermission() {
        try {
            return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public boolean available() {
        return ready();
    }

    @Override
    public ShellRunner.ExecResult exec(String script) {
        return exec(script, null);
    }

    @Override
    public ShellRunner.ExecResult exec(String script, byte[] stdinData) {
        try {
            Process p = openProcess(script);
            return ProcessIo.pump(p, stdinData, 90);
        } catch (Throwable t) {
            return new ShellRunner.ExecResult(-1, "", "Shizuku 通道执行失败: " + t);
        }
    }

    /**
     * Shizuku 13.x 把 newProcess 收成了私有方法，公开 API 只留 UserService。
     * 我们不需要那么重，直接反射拿那三个参数的版本，一次缓存，后面直接调。
     */
    private static java.lang.reflect.Method NEW_PROCESS;

    private static Process openProcess(String script) throws Exception {
        java.lang.reflect.Method m = NEW_PROCESS;
        if (m == null) {
            m = Shizuku.class.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class);
            m.setAccessible(true);
            NEW_PROCESS = m;
        }
        return (Process) m.invoke(null, new String[]{"sh", "-c", script}, null, null);
    }

    @Override
    public void close() {
        // Shizuku 是 binder，无需释放
    }
}
