package com.zaka.injector.inject;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.zaka.injector.core.AppConfig;
import com.zaka.injector.core.ByteName;
import com.zaka.injector.core.ChannelManager;
import com.zaka.injector.core.RootRunner;
import com.zaka.injector.core.ShellRunner;
import com.zaka.injector.core.ShizukuRunner;
import com.zaka.injector.log.InjectLog;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.List;
import java.util.Locale;

/**
 * 注入流水线。六步，任一步挂掉立刻停，状态栏给人话。
 *
 * 1 通道校验 → 2 环境检查 → 3 备份 → 4 释放 payload → 5 写入 → 6 回读校验
 */
public class DefaultInjectEngine implements InjectEngine {

    public static final int TOTAL = 6;

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean cancelled;

    public DefaultInjectEngine(Context ctx) {
        this.app = ctx.getApplicationContext();
    }

    /* ============================ 对外 ============================ */

    @Override
    public void cancel() {
        cancelled = true;
    }

    @Override
    public void run(final List<String> payloadNames, final Listener listener) {
        cancelled = false;
        new Thread(() -> doRun(payloadNames, listener), "zaka-inject").start();
    }

    @Override
    public void rollback(final Listener listener) {
        new Thread(() -> doRollback(listener), "zaka-rollback").start();
    }

    /* ============================ 主流程 ============================ */

    private void doRun(List<String> names, Listener l) {
        if (names == null || names.isEmpty()) {
            emit(l, StepEvent.skip(1, TOTAL, "通道校验", "一个开关都没开"));
            finish(l, false, "先打开至少一个功能开关");
            return;
        }

        /* ---- 1 通道校验 ---- */
        emit(l, StepEvent.running(1, TOTAL, "通道校验", "探测 Shizuku / Root…"));
        ShellRunner sh = resolveRunner();
        if (sh == null) {
            emit(l, StepEvent.fail(1, TOTAL, "通道校验", "没有可用通道"));
            InjectLog.e(app, "通道校验失败：Shizuku 未运行/未授权，Root 也不可用");
            finish(l, false, "没有可用通道，先开 Shizuku 或给 Root");
            return;
        }
        emit(l, StepEvent.ok(1, TOTAL, "通道校验", "通道：" + sh.name()));
        InjectLog.i(app, "通道 = " + sh.name());
        if (cancelled) {
            finish(l, false, "已取消");
            return;
        }

        /* ---- 2 环境检查 ---- */
        emit(l, StepEvent.running(2, TOTAL, "环境检查", "进程 + 目标目录…"));
        String pid = sh.exec("pidof " + AppConfig.TARGET_PKG
                + " 2>/dev/null; pgrep -f " + AppConfig.TARGET_PKG + " 2>/dev/null").out.trim();
        if (pid.isEmpty()) {
            emit(l, StepEvent.fail(2, TOTAL, "环境检查", "游戏没在跑"));
            InjectLog.e(app, "目标进程不在：" + AppConfig.TARGET_PKG);
            finish(l, false, "先把游戏跑起来再注入");
            return;
        }

        String dir = findTargetDir(sh);
        if (dir == null) {
            emit(l, StepEvent.fail(2, TOTAL, "环境检查", "目标目录都不存在"));
            InjectLog.e(app, "目标目录全部不存在，检查 AppConfig.TARGET_DIRS");
            finish(l, false, "没找到 LuaSource 目录，路径要改 AppConfig");
            return;
        }
        emit(l, StepEvent.ok(2, TOTAL, "环境检查", "pid " + firstLine(pid) + " · 目录已定位"));
        InjectLog.i(app, "目标目录 = " + dir);
        if (cancelled) {
            finish(l, false, "已取消");
            return;
        }

        /* ---- 3 备份 ---- */
        emit(l, StepEvent.running(3, TOTAL, "备份原文件", "带时间戳…"));
        File session;
        try {
            session = BackupManager.newSession(app);
        } catch (Throwable t) {
            emit(l, StepEvent.fail(3, TOTAL, "备份原文件", "建备份目录失败"));
            InjectLog.e(app, "建备份目录失败: " + t);
            finish(l, false, "备份目录建不出来，中止");
            return;
        }
        int backed = 0;
        for (String name : names) {
            String target = shellPath(dir, name);
            ShellRunner.ExecResult r = sh.exec("[ -f " + ByteName.sq(target) + " ] && base64 "
                    + ByteName.sq(target) + " || echo __NONE__");
            String body = r.out.replaceAll("\\s", "");
            if (body.contains("__NONE__") || body.isEmpty()) {
                continue;
            }
            try {
                byte[] original = android.util.Base64.decode(body, android.util.Base64.DEFAULT);
                BackupManager.save(session, name, dir, AppConfig.targetBytes(name), original);
                backed++;
            } catch (Throwable t) {
                InjectLog.e(app, "备份失败 " + name + ": " + t);
            }
        }
        emit(l, StepEvent.ok(3, TOTAL, "备份原文件",
                backed == 0 ? "原文件都不存在，按新增处理" : "已备份 " + backed + " 个 → " + session.getName()));
        if (cancelled) {
            finish(l, false, "已取消");
            return;
        }

        /* ---- 4 释放 payload ---- */
        emit(l, StepEvent.running(4, TOTAL, "释放 payload", "从 APK 解到私有目录…"));
        int released = 0;
        for (String name : names) {
            try {
                File f = PayloadManager.materialize(app, name);
                if (f.length() <= 0) {
                    emit(l, StepEvent.fail(4, TOTAL, "释放 payload", name + " 是空的"));
                    InjectLog.e(app, "payload 空文件: " + name);
                    finish(l, false, name + " 是空文件，检查 assets/payload");
                    return;
                }
                released++;
            } catch (Throwable t) {
                emit(l, StepEvent.fail(4, TOTAL, "释放 payload", t.getMessage()));
                InjectLog.e(app, "释放 payload 失败: " + name + " / " + t);
                finish(l, false, "APK 里缺 payload：" + name);
                return;
            }
        }
        emit(l, StepEvent.ok(4, TOTAL, "释放 payload", released + " 个就绪"));
        if (cancelled) {
            finish(l, false, "已取消");
            return;
        }

        /* ---- 5 写入 ---- */
        emit(l, StepEvent.running(5, TOTAL, "写入目标目录", "先落 tmp 再覆盖…"));
        int written = 0;
        for (String name : names) {
            byte[] data;
            try {
                data = readAll(new File(AppConfig.payloadDir(app), name));
            } catch (Throwable t) {
                emit(l, StepEvent.fail(5, TOTAL, "写入目标目录", name + " 读不出来"));
                InjectLog.e(app, "读 payload 失败: " + t);
                finish(l, false, "读 payload 失败：" + name);
                return;
            }

            String script = nameHead(dir, AppConfig.targetBytes(name))
                    + "cat > \"$T.zakatmp\" || exit 11\n"
                    + "mv -f \"$T.zakatmp\" \"$T\" || exit 12\n"
                    + "chmod 0644 \"$T\" 2>/dev/null\n"
                    + "echo __WRITTEN__";

            ShellRunner.ExecResult r = sh.exec(script, data);
            if (r.out.contains("__NAMEBAD__")) {
                emit(l, StepEvent.fail(5, TOTAL, "写入目标目录", "目标文件名构造异常"));
                InjectLog.e(app, "字节名转义没生效，已中止写入。out=" + r.out + " err=" + r.err);
                finish(l, false, "目标文件名没构造出来，已停手（看日志）");
                return;
            }
            if (!r.out.contains("__WRITTEN__")) {
                emit(l, StepEvent.fail(5, TOTAL, "写入目标目录", name + " 失败"));
                InjectLog.e(app, "写入失败 " + name + " → " + r);
                finish(l, false, "写入失败：" + name + "（看日志）");
                return;
            }
            written++;
            InjectLog.i(app, "写入 " + name + " (" + data.length + " 字节) → "
                    + AppConfig.readableName(AppConfig.targetBytes(name))
                    + "  @ " + dir);
        }
        emit(l, StepEvent.ok(5, TOTAL, "写入目标目录", written + " 个已落地"));
        if (cancelled) {
            finish(l, false, "已取消");
            return;
        }

        /* ---- 6 回读校验 ---- */
        emit(l, StepEvent.running(6, TOTAL, "回读校验", "长度 + 校验值…"));
        int passed = 0;
        for (String name : names) {
            String expect;
            try {
                expect = md5(readAll(new File(AppConfig.payloadDir(app), name)));
            } catch (Throwable t) {
                expect = "";
            }
            String script = nameHead(dir, AppConfig.targetBytes(name))
                    + "[ -f \"$T\" ] || { echo __MISSING__; exit 0; }\n"
                    + "wc -c < \"$T\"\n"
                    + "md5sum \"$T\"\n";

            ShellRunner.ExecResult r = sh.exec(script);
            String all = r.out;
            if (all.contains("__NAMEBAD__")) {
                emit(l, StepEvent.fail(6, TOTAL, "回读校验", "目标文件名构造异常"));
                InjectLog.e(app, "回读时字节名转义没生效，out=" + r.out + " err=" + r.err);
                finish(l, false, "目标文件名没构造出来，可点回滚");
                return;
            }
            if (all.contains("__MISSING__")) {
                emit(l, StepEvent.fail(6, TOTAL, "回读校验", name + " 没落上"));
                InjectLog.e(app, "回读失败，目标文件不存在: " + name);
                finish(l, false, "回读失败：" + name);
                return;
            }
            String got = extractMd5(all);
            if (expect.isEmpty() || !expect.equalsIgnoreCase(got)) {
                emit(l, StepEvent.fail(6, TOTAL, "回读校验", name + " 校验值对不上"));
                InjectLog.e(app, "校验不一致 " + name + " 期望=" + expect + " 实际=" + got);
                finish(l, false, "校验不一致：" + name + "，可点回滚");
                return;
            }
            passed++;
        }
        emit(l, StepEvent.ok(6, TOTAL, "回读校验", passed + " 个全部一致"));
        InjectLog.step(app, "注入完成，共 " + passed + " 个文件");
        finish(l, true, "搞定，" + passed + " 个文件已落地并校验通过");
    }

    /* ============================ 回滚 ============================ */

    private void doRollback(Listener l) {
        emit(l, StepEvent.running(1, TOTAL, "通道校验", "探测 Shizuku / Root…"));
        ShellRunner sh = resolveRunner();
        if (sh == null) {
            emit(l, StepEvent.fail(1, TOTAL, "通道校验", "没有可用通道"));
            finish(l, false, "没有可用通道");
            return;
        }
        emit(l, StepEvent.ok(1, TOTAL, "通道校验", "通道：" + sh.name()));

        emit(l, StepEvent.running(2, TOTAL, "环境检查", "找最近一次备份…"));
        File session = BackupManager.latestSession(app);
        if (session == null) {
            emit(l, StepEvent.fail(2, TOTAL, "环境检查", "没有备份"));
            finish(l, false, "没有可回滚的备份");
            return;
        }
        emit(l, StepEvent.ok(2, TOTAL, "环境检查", "备份：" + session.getName()));

        emit(l, StepEvent.running(3, TOTAL, "备份原文件", "读取备份清单…"));
        List<BackupManager.Item> items;
        try {
            items = BackupManager.load(session);
        } catch (Throwable t) {
            emit(l, StepEvent.fail(3, TOTAL, "备份原文件", "读取失败"));
            InjectLog.e(app, "备份读取失败: " + t);
            finish(l, false, "备份读取失败");
            return;
        }
        if (items.isEmpty()) {
            emit(l, StepEvent.fail(3, TOTAL, "备份原文件", "这份备份是空的"));
            finish(l, false, "备份里没有文件（当初可能是全新写入）");
            return;
        }
        emit(l, StepEvent.ok(3, TOTAL, "备份原文件", items.size() + " 个待还原"));

        emit(l, StepEvent.skip(4, TOTAL, "释放 payload", "回滚不需要这步"));

        emit(l, StepEvent.running(5, TOTAL, "写入目标目录", "逐个写回…"));
        int done = 0;
        for (BackupManager.Item it : items) {
            byte[] data;
            try {
                data = readAll(it.file);
            } catch (Throwable t) {
                InjectLog.e(app, "备份文件读取失败: " + it.payloadName);
                continue;
            }
            String script = nameHead(it.dir, it.nameBytes)
                    + "cat > \"$T.zakatmp\" || exit 11\n"
                    + "mv -f \"$T.zakatmp\" \"$T\" || exit 12\n"
                    + "chmod 0644 \"$T\" 2>/dev/null\n"
                    + "echo __WRITTEN__";
            ShellRunner.ExecResult r = sh.exec(script, data);
            if (r.out.contains("__WRITTEN__")) {
                done++;
                InjectLog.i(app, "回滚 " + it.payloadName);
            } else {
                InjectLog.e(app, "回滚失败 " + it.payloadName + " → " + r);
            }
        }
        if (done == 0) {
            emit(l, StepEvent.fail(5, TOTAL, "写入目标目录", "一个都没写回去"));
            finish(l, false, "回滚失败，看日志");
            return;
        }
        emit(l, StepEvent.ok(5, TOTAL, "写入目标目录", done + "/" + items.size() + " 已写回"));

        emit(l, StepEvent.ok(6, TOTAL, "回读校验", "完成"));
        InjectLog.step(app, "回滚完成 " + done + "/" + items.size());
        finish(l, true, "回滚完成：" + done + "/" + items.size());
    }

    /* ============================ 工具 ============================ */

    private ShellRunner resolveRunner() {
        ShellRunner sh = ChannelManager.cached();
        if (sh != null && sh.available()) {
            return sh;
        }
        ChannelManager.invalidate();
        ShizukuRunner sz = new ShizukuRunner();
        if (sz.available()) {
            return sz;
        }
        RootRunner rt = new RootRunner();
        if (rt.available()) {
            return rt;
        }
        return null;
    }

    private String findTargetDir(ShellRunner sh) {        StringBuilder sb = new StringBuilder();
        for (String d : AppConfig.TARGET_DIRS) {
            sb.append("[ -d ").append(ByteName.sq(d)).append(" ] && { echo \"__DIR__")
                    .append(d).append("\"; exit 0; }\n");
        }
        ShellRunner.ExecResult r = sh.exec(sb.toString());
        for (String line : r.out.split("\n")) {
            line = line.trim();
            if (line.startsWith("__DIR__")) {
                return line.substring("__DIR__".length());
            }
        }
        return null;
    }

    private String shellPath(String dir, String payloadName) {
        String oct = ByteName.octalEscapes(AppConfig.targetBytes(payloadName));
        return dir + "/$(printf '%b' '" + oct + "')";
    }

    /**
     * shell 头：把目标字节名算进 $N 并校验长度。
     * printf %b 万一没把 \0ddd 转义吃下去，$N 会变成一长串字面量，
     * 那就直接报 __NAMEBAD__ 停手，绝不往游戏目录写垃圾文件。
     */
    private static String nameHead(String dir, byte[] nameBytes) {
        return "D=" + ByteName.sq(dir) + "\n"
                + "N=$(printf '%b' " + ByteName.sq(ByteName.octalEscapes(nameBytes)) + ")\n"
                + "L=$(printf %s \"$N\" | wc -c | tr -d ' \\t')\n"
                + "[ \"$L\" = " + nameBytes.length + " ] || { echo __NAMEBAD__; exit 21; }\n"
                + "T=\"$D/$N\"\n";
    }

    private String targetDisplay(String dir, String payloadName) {
        byte[] raw = AppConfig.targetBytes(payloadName);
        StringBuilder sb = new StringBuilder(dir).append('/');
        for (byte b : raw) {
            sb.append(String.format(Locale.ROOT, "\\x%02x", b & 0xFF));
        }
        return sb.toString();
    }

    private static String extractMd5(String out) {
        for (String tok : out.split("\\s+")) {
            if (tok.matches("[0-9a-fA-F]{32}")) {
                return tok.toLowerCase(Locale.ROOT);
            }
        }
        return "";
    }

    private static String firstLine(String s) {
        int i = s.indexOf('\n');
        return (i > 0 ? s.substring(0, i) : s).trim();
    }

    private static byte[] readAll(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            int n;
            while (off < buf.length && (n = in.read(buf, off, buf.length - off)) > 0) {
                off += n;
            }
            byte[] out = new byte[off];
            System.arraycopy(buf, 0, out, 0, off);
            return out;
        }
    }

    static String md5(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] r = md.digest(data);
        StringBuilder sb = new StringBuilder(32);
        for (byte b : r) {
            sb.append(String.format(Locale.ROOT, "%02x", b & 0xFF));
        }
        return sb.toString();
    }

    private void emit(Listener l, StepEvent e) {
        main.post(() -> l.onStep(e));
    }

    private void finish(Listener l, boolean ok, String summary) {
        main.post(() -> l.onFinished(ok, summary));
    }
}
