package com.zaka.injector.inject;

/** 一步的状态事件，UI 直接拿来刷列表 */
public class StepEvent {

    public enum State {
        /** 正在跑 */
        RUNNING,
        /** 通过 */
        OK,
        /** 挂了 */
        FAIL,
        /** 跳过（比如开关全关） */
        SKIP
    }

    public final int index;
    public final int total;
    public final String title;
    public final State state;
    public final String detail;

    public StepEvent(int index, int total, String title, State state, String detail) {
        this.index = index;
        this.total = total;
        this.title = title;
        this.state = state;
        this.detail = detail == null ? "" : detail;
    }

    public static StepEvent running(int i, int n, String title, String detail) {
        return new StepEvent(i, n, title, State.RUNNING, detail);
    }

    public static StepEvent ok(int i, int n, String title, String detail) {
        return new StepEvent(i, n, title, State.OK, detail);
    }

    public static StepEvent fail(int i, int n, String title, String detail) {
        return new StepEvent(i, n, title, State.FAIL, detail);
    }

    public static StepEvent skip(int i, int n, String title, String detail) {
        return new StepEvent(i, n, title, State.SKIP, detail);
    }
}
