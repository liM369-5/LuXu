package com.zaka.injector.core;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.TimeUnit;

/** 进程输出抽取 —— 双线程排空，避免管道写满互相卡死 */
final class ProcessIo {

    private ProcessIo() {
    }

    static ShellRunner.ExecResult pump(Process p, byte[] stdinData, int timeoutSec) {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final ByteArrayOutputStream err = new ByteArrayOutputStream();

        Thread to = drain(p.getInputStream(), out);
        Thread te = drain(p.getErrorStream(), err);
        to.start();
        te.start();

        try {
            OutputStream os = p.getOutputStream();
            if (stdinData != null && stdinData.length > 0) {
                os.write(stdinData);
            }
            os.flush();
            os.close();
        } catch (Throwable ignored) {
            // 目标进程可能不读 stdin，正常
        }

        boolean finished;
        try {
            finished = p.waitFor(Math.max(1, timeoutSec), TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            finished = false;
        }
        if (!finished) {
            p.destroy();
        }

        join(to);
        join(te);

        int code = -1;
        if (finished) {
            try {
                code = p.exitValue();
            } catch (Throwable ignored) {
            }
        }
        return new ShellRunner.ExecResult(code, out.toString(), err.toString());
    }

    private static Thread drain(final InputStream in, final ByteArrayOutputStream sink) {
        Thread t = new Thread(() -> {
            byte[] buf = new byte[8192];
            try {
                int n;
                while ((n = in.read(buf)) > 0) {
                    sink.write(buf, 0, n);
                }
            } catch (Throwable ignored) {
            } finally {
                try {
                    in.close();
                } catch (Throwable ignored) {
                }
            }
        });
        t.setDaemon(true);
        return t;
    }

    private static void join(Thread t) {
        try {
            t.join(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
