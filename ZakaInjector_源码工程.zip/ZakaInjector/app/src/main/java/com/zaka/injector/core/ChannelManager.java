package com.zaka.injector.core;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import rikka.shizuku.Shizuku;

/**
 * 通道探测：Shizuku 优先，Root 兜底。
 * 探测在后台线程跑，结果回主线程。
 */
public final class ChannelManager {

    public interface Listener {
        /** runner 为 null 表示没通道，error 是人话原因 */
        void onResult(ShellRunner runner, String error);
    }

    private static volatile ShellRunner sCached;

    private ChannelManager() {
    }

    public static ShellRunner cached() {
        return sCached;
    }

    public static void invalidate() {
        sCached = null;
    }

    public static void detect(final Listener listener) {
        new Thread(() -> {
            ShellRunner found = null;
            try {
                ShizukuRunner sz = new ShizukuRunner();
                if (sz.available()) {
                    found = sz;
                }
            } catch (Throwable ignored) {
            }
            if (found == null) {
                try {
                    RootRunner rt = new RootRunner();
                    if (rt.available()) {
                        found = rt;
                    }
                } catch (Throwable ignored) {
                }
            }

            String err = null;
            if (found == null) {
                err = ShizukuRunner.needPermission()
                        ? "Shizuku 在跑，但本应用还没拿到授权 —— 点下面按钮授权"
                        : "没有可用通道：Shizuku 没开，也没拿到 Root";
            }
            sCached = found;

            final ShellRunner f = found;
            final String e = err;
            new Handler(Looper.getMainLooper()).post(() -> listener.onResult(f, e));
        }, "zaka-channel-detect").start();
    }

    /** 拉起 Shizuku 授权弹窗，必须在主线程、Activity 存活时调用 */
    public static boolean requestShizuku(Activity a) {
        try {
            if (!Shizuku.pingBinder()) {
                return false;
            }
            Shizuku.requestPermission(ShizukuRunner.PERMISSION_CODE);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
