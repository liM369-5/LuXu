package com.zaka.injector.core;

/**
 * 游戏 LuaSource 目录的字节名规则：0xFF − 字符码。
 * 一字对一字、等长，只吃单字节字符（中文名编不出来）。
 */
public final class ByteName {

    private ByteName() {
    }

    /** 明文名 → 游戏字节名 */
    public static byte[] encode(String plain) {
        if (plain == null || plain.isEmpty()) {
            throw new IllegalArgumentException("名字不能为空");
        }
        byte[] out = new byte[plain.length()];
        for (int i = 0; i < plain.length(); i++) {
            char c = plain.charAt(i);
            if (c > 0xFF) {
                throw new IllegalArgumentException("字节名只支持单字节字符，越界字符: " + c);
            }
            out[i] = (byte) (0xFF - (c & 0xFF));
        }
        return out;
    }

    /** 游戏字节名 → 明文名 */
    public static String decode(byte[] raw) {
        StringBuilder sb = new StringBuilder(raw.length);
        for (byte b : raw) {
            sb.append((char) (0xFF - (b & 0xFF)));
        }
        return sb.toString();
    }

    /**
     * 生成 shell 可用的八进制转义串，配合 printf '%b' 使用。
     * 写成 POSIX 规定的 \0ddd 形式（d = 八进制数字，最多三位），
     * bash / dash / Android 的 mksh 全认，避开了引号地狱和编码转换。
     */
    public static String octalEscapes(byte[] raw) {
        StringBuilder sb = new StringBuilder(raw.length * 5);
        for (byte b : raw) {
            int v = b & 0xFF;
            sb.append("\\0");
            sb.append((char) ('0' + ((v >> 6) & 7)));
            sb.append((char) ('0' + ((v >> 3) & 7)));
            sb.append((char) ('0' + (v & 7)));
        }
        return sb.toString();
    }

    /** shell 单引号安全包裹 */
    public static String sq(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }
}
