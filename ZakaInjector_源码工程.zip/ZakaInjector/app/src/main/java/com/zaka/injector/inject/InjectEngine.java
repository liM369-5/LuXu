package com.zaka.injector.inject;

import java.util.List;

/** 注入器对外的唯一入口 */
public interface InjectEngine {

    interface Listener {
        /** 注意：可能不在主线程 */
        void onStep(StepEvent e);

        /** 注意：可能不在主线程 */
        void onFinished(boolean ok, String summary);
    }

    /** payloadNames = 本次要落地的文件（就是 AppConfig.SWITCHES 里打开那些） */
    void run(List<String> payloadNames, Listener listener);

    /** 用最近一次备份回滚 */
    void rollback(Listener listener);

    void cancel();
}
