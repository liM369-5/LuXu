package com.zaka.injector.log;

import android.content.Context;

import com.zaka.injector.core.AppConfig;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** 全程写 inject.log，面板里直接能看 */
public final class InjectLog {

    private static final Object LOCK = new Object();
    /** 北京时间 */
    private static final SimpleDateFormat FMT =
            new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA);
    private static final long MAX_SIZE = 512 * 1024L;

    private InjectLog() {
    }

    public static void i(Context ctx, String msg) {
        write(ctx, "INFO", msg);
    }

    public static void e(Context ctx, String msg) {
        write(ctx, "ERR ", msg);
    }

    public static void step(Context ctx, String msg) {
        write(ctx, "STEP", msg);
    }

    private static void write(Context ctx, String level, String msg) {
        synchronized (LOCK) {
            String line = "[" + FMT.format(new Date()) + "] [" + level + "] " + msg + "\n";
            File f = AppConfig.logFile(ctx);
            try {
                if (f.exists() && f.length() > MAX_SIZE) {
                    // 超了就直接重开，不做花哨轮转
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
                FileOutputStream fos = new FileOutputStream(f, true);
                fos.write(line.getBytes("UTF-8"));
                fos.flush();
                fos.close();
            } catch (Throwable ignored) {
            }
        }
    }

    /** 取最后 maxLines 行 */
    public static String tail(Context ctx, int maxLines) {
        synchronized (LOCK) {
            File f = AppConfig.logFile(ctx);
            if (!f.exists()) {
                return "(还没有日志)";
            }
            ArrayDeque<String> q = new ArrayDeque<>();
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String l;
                while ((l = br.readLine()) != null) {
                    if (q.size() >= maxLines) {
                        q.pollFirst();
                    }
                    q.addLast(l);
                }
            } catch (Throwable t) {
                return "(日志读取失败: " + t.getMessage() + ")";
            }
            if (q.isEmpty()) {
                return "(还没有日志)";
            }
            StringBuilder sb = new StringBuilder();
            for (String s : q) {
                sb.append(s).append('\n');
            }
            return sb.toString().trim();
        }
    }

    public static void clear(Context ctx) {
        synchronized (LOCK) {
            try {
                RandomAccessFile raf = new RandomAccessFile(AppConfig.logFile(ctx), "rw");
                raf.setLength(0);
                raf.close();
            } catch (Throwable ignored) {
            }
        }
    }
}
