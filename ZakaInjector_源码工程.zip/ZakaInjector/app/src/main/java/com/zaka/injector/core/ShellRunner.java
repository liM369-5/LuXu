package com.zaka.injector.core;

/**
 * 统一权限通道。上层只认这一个接口，不管底下是 Shizuku 还是 Root。
 */
public interface ShellRunner {

    /** 通道名，显示用 */
    String name();

    /** 当前是否可用 */
    boolean available();

    /** 执行一段 shell 脚本 */
    ExecResult exec(String script);

    /** 执行一段 shell 脚本，并把 stdinData 喂给它的标准输入 */
    ExecResult exec(String script, byte[] stdinData);

    /** 释放资源 */
    void close();

    final class ExecResult {
        public final int code;
        public final String out;
        public final String err;

        public ExecResult(int code, String out, String err) {
            this.code = code;
            this.out = out == null ? "" : out;
            this.err = err == null ? "" : err;
        }

        public boolean ok() {
            return code == 0;
        }

        /** 人话版输出 */
        public String message() {
            String s = out.trim();
            if (s.isEmpty()) {
                s = err.trim();
            }
            return s;
        }

        @Override
        public String toString() {
            return "exit=" + code + " | out=" + out.trim() + " | err=" + err.trim();
        }
    }
}
