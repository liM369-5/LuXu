package com.zaka.injector.core;

import android.content.Context;

import java.io.File;

/**
 * 全部可配置项集中在这个文件里。
 * 换游戏 / 换路径 / 加功能开关 —— 只改这个文件，其它代码一个字都不用动。
 */
public final class AppConfig {

    private AppConfig() {
    }

    /* ==================================================================
     * 1. 目标游戏
     * ================================================================== */

    /** 目标包名 —— 换成你要注入的那个游戏 */
    public static final String TARGET_PKG = "com.tencent.tmgp.dfm";

    /** 面板上显示的名字 */
    public static final String TARGET_NAME = "三角洲行动";

    /* ==================================================================
     * 2. 目标目录
     * 自上而下逐个探测，第一个「真实存在」的目录会被选中。
     * 不确定就多写几条，程序自己挑。
     * ================================================================== */

    public static final String[] TARGET_DIRS = {
            "/storage/emulated/0/Android/data/" + TARGET_PKG
                    + "/files/UE4Game/DeltaForce/DeltaForce/Saved/LuaSource",
            "/storage/emulated/0/Android/data/" + TARGET_PKG
                    + "/files/UE4Game/DeltaForce/Saved/LuaSource",
            "/storage/emulated/0/Android/data/" + TARGET_PKG
                    + "/files/UE4Game/DFM/DFM/Saved/LuaSource",
            "/storage/emulated/0/Android/data/" + TARGET_PKG
                    + "/files/UE4Game/DFM/Saved/LuaSource",
            "/storage/emulated/0/Android/data/" + TARGET_PKG
                    + "/files/UE4Game/DeltaForceMobile/DeltaForceMobile/Saved/LuaSource",
            "/storage/emulated/0/Android/data/" + TARGET_PKG + "/files/LuaSource",
    };

    /* ==================================================================
     * 3. payload（APK 自带，注入时释放到私有目录再落地）
     *
     * asset  = APK 里 assets/payload/ 下的文件名，纯 ASCII，别用字节名，
     *          免得构建工具做编码转换把名字搞坏。
     * target = 游戏 Saved/LuaSource/ 里的原始字节名，逐字节写死。
     *          ⚠ 这里是一个字节都不许改的东西：名字错一个字节 = 覆盖不生效。
     *          所以不做任何「明文名 → 编码」的换算，直接列出原始字节。
     * ================================================================== */

    /** 装备校验模块（原版字节码）：DFM.BUSINESS.MODULE.ARMEDFORCEMODULE.LOGIC.EQUIPMENT.CHECKEQUIPLOGIC.LUA */
    private static final byte[] MODULE_CHECKEQUIP = {
            (byte) 0xBB, (byte) 0xB9, (byte) 0xB2, (byte) 0xF1, (byte) 0xBD, (byte) 0xAA, (byte) 0xAC, (byte) 0xB6, (byte) 0xB1, (byte) 0xBA, (byte) 0xAC, (byte) 0xAC,
            (byte) 0xF1, (byte) 0xB2, (byte) 0xB0, (byte) 0xBB, (byte) 0xAA, (byte) 0xB3, (byte) 0xBA, (byte) 0xF1, (byte) 0xBE, (byte) 0xAD, (byte) 0xB2, (byte) 0xBA,
            (byte) 0xBB, (byte) 0xB9, (byte) 0xB0, (byte) 0xAD, (byte) 0xBC, (byte) 0xBA, (byte) 0xB2, (byte) 0xB0, (byte) 0xBB, (byte) 0xAA, (byte) 0xB3, (byte) 0xBA,
            (byte) 0xF1, (byte) 0xB3, (byte) 0xB0, (byte) 0xB8, (byte) 0xB6, (byte) 0xBC, (byte) 0xF1, (byte) 0xBA, (byte) 0xAE, (byte) 0xAA, (byte) 0xB6, (byte) 0xAF,
            (byte) 0xB2, (byte) 0xBA, (byte) 0xB1, (byte) 0xAB, (byte) 0xF1, (byte) 0xBC, (byte) 0xB7, (byte) 0xBA, (byte) 0xBC, (byte) 0xB4, (byte) 0xBA, (byte) 0xAE,
            (byte) 0xAA, (byte) 0xB6, (byte) 0xAF, (byte) 0xB3, (byte) 0xB0, (byte) 0xB8, (byte) 0xB6, (byte) 0xBC, (byte) 0xF1, (byte) 0xB3, (byte) 0xAA, (byte) 0xBE,
    };

    /** 开关表：面板上一条开关 = 这里一行。加功能就往后面加一行。 */
    public static final SwitchDef[] SWITCHES = {
            new SwitchDef("装备校验模块", "CHECKEQUIPLOGIC.LUA", true, MODULE_CHECKEQUIP),
    };

    public static final class SwitchDef {
        /** 面板上显示的名字 */
        public final String label;
        /** APK 内 assets/payload/ 下的文件名（ASCII） */
        public final String asset;
        /** 进来默认开不开 */
        public final boolean defaultOn;

        private final byte[] targetName;

        SwitchDef(String label, String asset, boolean defaultOn, byte[] targetName) {
            this.label = label;
            this.asset = asset;
            this.defaultOn = defaultOn;
            this.targetName = targetName.clone();
        }

        /** 游戏侧文件名原始字节（返回副本，外面改不到表） */
        public byte[] targetName() {
            return targetName.clone();
        }
    }

    /** payload key（= asset 名）→ 游戏侧原始字节名 */
    public static byte[] targetBytes(String asset) {
        for (SwitchDef d : SWITCHES) {
            if (d.asset.equals(asset)) {
                return d.targetName();
            }
        }
        // 表里没登记的，退回按 0xFF − 字符码 现编
        return ByteName.encode(asset);
    }

    /** 字节名 → 能看的名（不可打印字节显示成点），给日志和界面用 */
    public static String readableName(byte[] raw) {
        StringBuilder sb = new StringBuilder(raw.length);
        for (byte b : raw) {
            char c = (char) (b & 0xFF);
            sb.append(c >= 0x20 && c < 0x7F ? c : '.');
        }
        return sb.toString();
    }

    /* ==================================================================
     * 4. 运行路径（不用改）
     * ================================================================== */

    /** App 自己的外部私有目录：Android 11+ 别的 App 和普通文件管理器都进不来 */
    public static File home(Context ctx) {
        File f = ctx.getExternalFilesDir(null);
        return f != null ? f : ctx.getFilesDir();
    }

    /** payload 释放目录 */
    public static File payloadDir(Context ctx) {
        return new File(home(ctx), "payload");
    }

    /** 备份目录 */
    public static File backupDir(Context ctx) {
        File f = new File(home(ctx), "backup");
        if (!f.exists()) {
            //noinspection ResultOfMethodCallIgnored
            f.mkdirs();
        }
        return f;
    }

    /** 日志文件 */
    public static File logFile(Context ctx) {
        return new File(home(ctx), "inject.log");
    }

    /** shell 侧的临时落脚点 */
    public static final String SHELL_TMP = "/data/local/tmp/zaka_inject";
}
