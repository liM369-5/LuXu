package com.zaka.injector.inject;

import android.content.Context;

import com.zaka.injector.core.AppConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * payload 管理：APK 自带 → 释放到 App 自己的外部私有目录。
 * shell 通道能从这个目录读走，普通 App / 文件管理器进不来。
 */
public final class PayloadManager {

    private PayloadManager() {
    }

    /** 把 assets/payload/<name> 释放到私有目录，返回落地后的文件 */
    public static File materialize(Context ctx, String name) throws IOException {
        File dir = AppConfig.payloadDir(ctx);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("创建 payload 目录失败");
        }
        File out = new File(dir, name);

        InputStream is;
        try {
            is = ctx.getAssets().open("payload/" + name);
        } catch (IOException e) {
            throw new IOException("APK 里没有 payload/" + name);
        }

        FileOutputStream fos = new FileOutputStream(out);
        try {
            byte[] buf = new byte[16384];
            int n;
            while ((n = is.read(buf)) > 0) {
                fos.write(buf, 0, n);
            }
            fos.flush();
        } finally {
            try {
                fos.close();
            } catch (Throwable ignored) {
            }
            try {
                is.close();
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    /** APK 里 payload 目录下的全部文件名 */
    public static List<String> listBuiltin(Context ctx) {
        List<String> out = new ArrayList<>();
        try {
            String[] names = ctx.getAssets().list("payload");
            if (names != null) {
                Arrays.sort(names);
                for (String n : names) {
                    if (!n.startsWith(".") && !n.endsWith(".txt")) {
                        out.add(n);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }
}
