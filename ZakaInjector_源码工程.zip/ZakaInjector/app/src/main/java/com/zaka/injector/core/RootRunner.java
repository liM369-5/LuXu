package com.zaka.injector.core;

/** Root 通道（备用）：直接走 su */
public class RootRunner implements ShellRunner {

    private Boolean cached;

    @Override
    public String name() {
        return "Root";
    }

    @Override
    public boolean available() {
        if (cached != null) {
            return cached;
        }
        try {
            Process p = new ProcessBuilder("su", "-c", "id").redirectErrorStream(false).start();
            ShellRunner.ExecResult r = ProcessIo.pump(p, null, 8);
            cached = r.ok() && r.out.contains("uid=0");
        } catch (Throwable t) {
            cached = false;
        }
        return cached;
    }

    @Override
    public ShellRunner.ExecResult exec(String script) {
        return exec(script, null);
    }

    @Override
    public ShellRunner.ExecResult exec(String script, byte[] stdinData) {
        try {
            Process p = new ProcessBuilder("su", "-c", script).start();
            return ProcessIo.pump(p, stdinData, 90);
        } catch (Throwable t) {
            return new ShellRunner.ExecResult(-1, "", "Root 通道执行失败: " + t);
        }
    }

    @Override
    public void close() {
        cached = null;
    }
}
