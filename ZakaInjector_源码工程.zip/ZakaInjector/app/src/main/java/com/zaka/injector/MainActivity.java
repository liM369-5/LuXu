package com.zaka.injector;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.zaka.injector.core.ChannelManager;
import com.zaka.injector.inject.PayloadManager;
import com.zaka.injector.log.InjectLog;
import com.zaka.injector.perm.PermHelper;
import com.zaka.injector.ui.FloatingService;
import com.zaka.injector.ui.Theme;

import java.util.List;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_NOTIFY = 0x1001;

    /** 页面左右留白 */
    private static final float PAD_H = 20f;
    /** 状态栏下面再让这么多，别贴着 */
    private static final float PAD_TOP_BASE = 26f;
    private static final float PAD_BOTTOM_BASE = 28f;

    private ScrollView page;
    private LinearLayout root;

    private TextView overlayState;
    private TextView notifyState;
    private TextView channelState;
    private TextView payloadState;
    private TextView logText;
    private ScrollView logScroll;

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> refresh();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Shizuku.addRequestPermissionResultListener(permListener);
        } catch (Throwable ignored) {
        }
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        refreshLog();
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    /* ============================ 边缘贴合 ============================ */

    /**
     * 顶部黑边的根因：窗口背景透明 + 状态栏透明 → 状态栏区域透出黑底。
     * 这里把状态栏/导航栏设成全透明，内容延伸到系统栏下方，页面自己的底色铺满整屏，
     * 系统栏图标按深浅色切成深色（浅底）/ 浅色（深底）。
     */
    private void applyEdgeToEdge() {
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            // 关掉系统给系统栏自动加的那层半透明"遮罩"，否则顶部还是会有一条灰黑
            w.setStatusBarContrastEnforced(false);
            w.setNavigationBarContrastEnforced(false);
        }
        boolean dark = Theme.dark(this);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (!dark) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }
        w.getDecorView().setSystemUiVisibility(flags);
    }

    /* ============================ UI ============================ */

    private void buildUi() {
        applyEdgeToEdge();

        page = new ScrollView(this);
        page.setBackgroundColor(Theme.pageBg(this));
        page.setFillViewport(true);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        page.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(page);

        // 系统栏 inset 打到 page 上，内容永远不被状态栏压住
        page.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(PAD_H), dp(PAD_TOP_BASE) + top, dp(PAD_H), dp(PAD_BOTTOM_BASE) + bottom);
            return insets;
        });
        page.requestApplyInsets();

        /* ---- 标题区 ---- */

        TextView brand = new TextView(this);
        brand.setText("陆续注入器");
        brand.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        brand.setTextColor(Theme.text(this));
        brand.setIncludeFontPadding(false);
        root.addView(brand, wrap());

        TextView mark = new TextView(this);
        mark.setText("LX");
        mark.setTextSize(TypedValue.COMPLEX_UNIT_SP, 52);
        mark.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        mark.setTextColor(Theme.text(this));
        mark.setIncludeFontPadding(false);
        LinearLayout.LayoutParams mlp = wrap();
        mlp.topMargin = dp(6);
        mlp.bottomMargin = dp(20);
        root.addView(mark, mlp);

        /* ---- 状态卡片 ---- */

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        card.setBackground(round(Theme.cardBg(this), dp(20)));
        overlayState = stateRow(card, "悬浮窗权限");
        notifyState = stateRow(card, "通知权限");
        channelState = stateRow(card, "权限通道");
        payloadState = stateRow(card, "payload");
        root.addView(card);

        /* ---- 按钮 ---- */

        root.addView(button("启动悬浮球", true, v -> {
            if (!PermHelper.canOverlay(this)) {
                PermHelper.requestOverlay(this);
                toast("先给悬浮窗权限");
                return;
            }
            FloatingService.show(this);
            toast("悬浮球已启动");
            moveTaskToBack(true);
        }));

        root.addView(button("授权 Shizuku", false, v -> {
            if (!ChannelManager.requestShizuku(this)) {
                toast("Shizuku 没在跑，先启动 Shizuku 服务");
            }
        }));

        /* ---- 日志卡片 ---- */

        LinearLayout logCard = new LinearLayout(this);
        logCard.setOrientation(LinearLayout.VERTICAL);
        logCard.setPadding(dp(16), dp(14), dp(16), dp(16));
        logCard.setBackground(round(Theme.cardBg(this), dp(20)));
        LinearLayout.LayoutParams lclp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lclp.topMargin = dp(10);
        logCard.setLayoutParams(lclp);

        LinearLayout logHead = new LinearLayout(this);
        logHead.setOrientation(LinearLayout.HORIZONTAL);
        logHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView logTitle = new TextView(this);
        logTitle.setText("注入日志");
        logTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        logTitle.setTypeface(Typeface.DEFAULT_BOLD);
        logTitle.setTextColor(Theme.text(this));
        logHead.addView(logTitle, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView clear = new TextView(this);
        clear.setText("清空");
        clear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        clear.setTextColor(Theme.subText(this));
        clear.setPadding(dp(12), dp(6), dp(4), dp(6));
        clear.setOnClickListener(v -> {
            InjectLog.clear(this);
            refreshLog();
            toast("日志已清空");
        });
        logHead.addView(clear);
        logCard.addView(logHead);

        logScroll = new ScrollView(this);
        logScroll.setBackground(innerBox());
        logScroll.setPadding(dp(12), dp(10), dp(12), dp(10));
        logScroll.setVerticalScrollBarEnabled(true);
        LinearLayout.LayoutParams lslp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
        lslp.topMargin = dp(10);
        logScroll.setLayoutParams(lslp);

        logText = new TextView(this);
        logText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setTextColor(Theme.text(this));
        logText.setLineSpacing(dp(2), 1f);
        logText.setTextIsSelectable(true);
        logScroll.addView(logText, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        logCard.addView(logScroll);
        root.addView(logCard);
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private TextView stateRow(LinearLayout parent, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(7), 0, dp(7));

        TextView lb = new TextView(this);
        lb.setText(label);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        lb.setTextColor(Theme.text(this));
        row.addView(lb, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView val = new TextView(this);
        val.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        val.setTextColor(Theme.subText(this));
        val.setGravity(Gravity.END);
        row.addView(val);

        parent.addView(row);
        return val;
    }

    private TextView button(String text, boolean primary, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        if (primary) {
            b.setTextColor(0xFFFFFFFF);
            b.setBackground(round(Theme.accent(), dp(15)));
        } else {
            b.setTextColor(Theme.text(this));
            b.setBackground(round(Theme.cardBg(this), dp(15)));
        }
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    /* ============================ 状态 ============================ */

    private void refresh() {
        // 悬浮窗
        boolean ov = PermHelper.canOverlay(this);
        mark(overlayState, ov ? "已授权" : "未授权 · 点一下去开", ov);

        // 通知
        boolean nt = PermHelper.canNotify(this);
        mark(notifyState, nt ? "已授权" : "未授权", nt);

        // 通道
        channelState.setText("检测中…");
        channelState.setTextColor(Theme.subText(this));
        ChannelManager.detect((runner, error) -> {
            if (runner != null) {
                mark(channelState, runner.name() + " 可用", true);
            } else {
                mark(channelState, error == null ? "无" : "无 · 开 Shizuku 或给 Root", false);
            }
        });

        // payload
        List<String> builtin = PayloadManager.listBuiltin(this);
        if (builtin.isEmpty()) {
            mark(payloadState, "APK 里没放文件", false);
        } else {
            String first = builtin.get(0);
            mark(payloadState, builtin.size() == 1 ? first : first + " 等 " + builtin.size() + " 个", true);
        }
    }

    private void refreshLog() {
        if (logText == null || logScroll == null) {
            return;
        }
        logText.setText(InjectLog.tail(this, 400));
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void mark(TextView v, String text, boolean good) {
        v.setText(text);
        v.setTextColor(good ? Theme.okColor() : Theme.warnColor());
    }

    /* ============================ 小工具 ============================ */

    private int dp(float v) {
        return Theme.dp(this, v);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    /** 日志内嵌框：比卡片再深一档 + 一根细边 */
    private GradientDrawable innerBox() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Theme.innerBg(this));
        d.setCornerRadius(dp(12));
        d.setStroke(Math.max(1, dp(1)), Theme.divider(this));
        return d;
    }
}
