package com.zaka.injector.inject;

import android.content.Context;

import com.zaka.injector.core.AppConfig;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 备份 / 回滚。
 * 备份落在 App 私有目录：backup/<时间戳>/<payload 名>.bin + _meta.txt
 * _meta.txt 每行记录：payload名 \t 目标目录 \t 目标文件名字节(hex，可空)
 * 记 hex 是为了还原时直接用原字节名，不重算，避开一切编码偏差。
 */
public final class BackupManager {

    private static final String META = "_meta.txt";
    private static final SimpleDateFormat TS =
            new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA);

    private BackupManager() {
    }

    public static class Item {
        public final File file;
        public final String payloadName;
        public final String dir;
        /** 目标文件的原始字节名（还原时直接用，不再重算，避免任何编码偏差） */
        public final byte[] nameBytes;

        Item(File file, String payloadName, String dir, byte[] nameBytes) {
            this.file = file;
            this.payloadName = payloadName;
            this.dir = dir;
            this.nameBytes = nameBytes;
        }
    }

    public static File newSession(Context ctx) throws IOException {
        File root = AppConfig.backupDir(ctx);
        File s = new File(root, TS.format(new Date()));
        if (!s.exists() && !s.mkdirs()) {
            throw new IOException("创建备份目录失败");
        }
        return s;
    }

    public static void save(File session, String payloadName, String dir,
                            byte[] nameBytes, byte[] original) throws IOException {
        File bin = new File(session, payloadName + ".bin");
        try (FileOutputStream fos = new FileOutputStream(bin)) {
            fos.write(original);
        }
        try (FileOutputStream fos = new FileOutputStream(new File(session, META), true)) {
            fos.write((payloadName + "\t" + dir + "\t" + hex(nameBytes) + "\n")
                    .getBytes(StandardCharsets.UTF_8));
        }
    }

    public static File latestSession(Context ctx) {
        File root = AppConfig.backupDir(ctx);
        File[] list = root.listFiles();
        if (list == null || list.length == 0) {
            return null;
        }
        Arrays.sort(list, (a, b) -> b.getName().compareTo(a.getName()));
        for (File f : list) {
            if (f.isDirectory()) {
                return f;
            }
        }
        return null;
    }

    public static List<Item> load(File session) throws IOException {
        List<Item> out = new ArrayList<>();
        File meta = new File(session, META);
        if (!meta.exists()) {
            return out;
        }
        for (String line : readLines(meta)) {
            String[] parts = line.split("\t");
            if (parts.length < 2) {
                continue;
            }
            String name = parts[0];
            String dir = parts[1];
            byte[] nameBytes = parts.length >= 3 ? unhex(parts[2]) : null;
            if (nameBytes == null) {
                nameBytes = AppConfig.targetBytes(name);
            }
            File bin = new File(session, name + ".bin");
            if (bin.exists()) {
                out.add(new Item(bin, name, dir, nameBytes));
            }
        }
        return out;
    }

    private static String hex(byte[] raw) {
        StringBuilder sb = new StringBuilder(raw.length * 2);
        for (byte b : raw) {
            sb.append(String.format(Locale.ROOT, "%02x", b & 0xFF));
        }
        return sb.toString();
    }

    private static byte[] unhex(String s) {
        s = s.trim();
        if (s.isEmpty() || (s.length() & 1) != 0) {
            return null;
        }
        try {
            byte[] out = new byte[s.length() / 2];
            for (int i = 0; i < out.length; i++) {
                out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
            }
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private static List<String> readLines(File f) throws IOException {
        List<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String l;
            while ((l = br.readLine()) != null) {
                if (!l.trim().isEmpty()) {
                    out.add(l);
                }
            }
        }
        return out;
    }
}
